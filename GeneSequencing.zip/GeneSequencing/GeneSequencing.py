#!/usr/bin/python3
from past.builtins import xrange

from which_pyqt import PYQT_VER
if PYQT_VER == 'PYQT5':
	from PyQt5.QtCore import QLineF, QPointF
elif PYQT_VER == 'PYQT4':
	from PyQt4.QtCore import QLineF, QPointF
else:
	raise Exception('Unsupported Version of PyQt: {}'.format(PYQT_VER))

import math
import sys
import time
import itertools
# Used to compute the bandwidth for banded version
MAXINDELS = 3

# Used to implement Needleman-Wunsch scoring
MATCH = -3
INDEL = 5
SUB = 1

sys.setrecursionlimit(5000)
class GeneSequencing:

	def __init__( self ):
		self.alignmentA = []
		self.alignmentB = []
		pass

	def solution(self, table, m, n, A, B,):
		if m == 0 and n == 0:
			return
		insert = table[m][n-1]+INDEL if n != 0 else math.inf
		diff = SUB if A[m - 1] != B[n - 1] else MATCH
		match = (table[m][n - 1]+diff
				if m != 0 and n !=0
				else math.inf)
		delete = table[m-1][n]+INDEL if m != 0 else math.inf

		results = min(insert,match,delete)

		if results == insert:
			self.alignmentA.append("-")
			self.alignmentB.append(B[n-1])
			return self.solution(table,m,n-1,A,B)
		elif results == match:
			self.alignmentA.append(A[m-1])
			self.alignmentB.append((B[n-1]))
			return self.solution(table,m-1,n-1,A,B)
		else:
			self.alignmentA.append(A[m-1])
			self.alignmentB.append("-")
			return self.solution(table, m-1, n,A,B)


	def scoring_banded(self, A, B): # Runtime: O(kn)
		self.alignmentA.clear()
		self.alignmentB.clear()
		m = MAXINDELS
		n = MAXINDELS
		score_table = [[0 for i in range(2 * MAXINDELS + 1)] for j in range(len(A) + 1)] #O(kn)
		def table_pos(i, j): #O(1)
			return i, j - i + MAXINDELS

		def set_score(i, j, value): #O(1)
			i2, j2 = table_pos(i, j)
			score_table[i2][j2] = value

		def get(i, j): #O(1)
			i2, j2 = table_pos(i, j)
			if not 0 <= j2 < 2 * MAXINDELS + 1:
				return math.inf
			return score_table[i2][j2]

		for i in range(1, MAXINDELS + 1): #O(k)
			score_table[i][0] = INDEL * i
		for j in range(1, MAXINDELS + 1): #O(k)
			score_table[0][j] = INDEL * j
		for i in range(1, len(A) + 1): #O(kn)
			for j in range(max(1, i - MAXINDELS), min(len(B), i + MAXINDELS) + 1): #O(k)
				diff = SUB if A[i - 1] != B[j - 1] else MATCH
				is_matching = get(i - 1, j - 1) + diff
				is_deleted = get(i - 1, j) + INDEL
				is_inserted = get(i, j - 1) + INDEL
				result = min(is_matching, is_deleted, is_inserted)
				set_score(i,j,result)

		self.solution(score_table,m,n,A,B)
		self.alignmentA.reverse()
		self.alignmentB.reverse()
		return get(len(A), len(B)),str(self.alignmentA), str(self.alignmentB)

	def scoring(self,A, B): #Runtime: O(mn)
		self.alignmentA.clear()
		self.alignmentB.clear()
		m = len(A)
		n = len(B)
		score_table = [[0 for i in range(len(B)+1)] for j in range(len(A)+1)] #O(mn)
		for i in range(1,len(A)+1): #O(m)
			score_table[i][0] = INDEL * i
		for j in range(1,len(B)+1): #O(n)
			score_table[0][j] = INDEL * j
		for i in range(1, len(A)+1): #O(mn)
			for j in range(1, len(B)+1): #O(n)
				diff = SUB if A[i - 1] != B[j - 1] else MATCH
				result = min(score_table[i - 1][j]+ INDEL, score_table[i][j - 1] + INDEL, score_table[i - 1][j - 1] + diff)
				score_table[i][j] = result

		self.solution(score_table,m,n,A,B)
		self.alignmentA.reverse()
		self.alignmentB.reverse()
		return (score_table[m][n],str(self.alignmentA),str(self.alignmentB))
# This is the method called by the GUI.  _sequences_ is a list of the ten sequences, _table_ is a
# handle to the GUI so it can be updated as you find results, _banded_ is a boolean that tells
# you whether you should compute a banded alignment or full alignment, and _align_length_ tells you
# how many base pairs to use in computing the alignment

	def align( self, sequences, table, banded, align_length):
		self.banded = banded
		self.MaxCharactersToAlign = align_length
		results = []
		sequencedi = [0 for i in range(align_length)]
		sequencedj = [0 for j in range(align_length)]


		for i in range(len(sequences)):
			jresults = []
			for j in range(len(sequences)):

				if(j < i):
					s = {}
				else:
					if align_length > len(sequences[i]):
						sequencedi = sequences[i]
					if align_length > len(sequences[j]):
						sequencedj = sequences[j]
					else:
						sequencedi = sequences[i][:align_length]
						sequencedj = sequences[j][:align_length]
###################################################################################################
# your code should replace these three statements and populate the three variables: score, alignment1 and alignment2
					if(banded):
						score,alignment1,alignment2 = self.scoring_banded(sequencedi,sequencedj)
					else:
						score,alignment1,alignment2 = self.scoring(sequencedi,sequencedj)
					#score = value[len(sequencedi)][len(sequencedj)]
					#alignment1 = 'abc-easy  DEBUG:(seq{}, {} chars,align_len={}{})'.format(i+1,
					#	len(sequences[i]), align_length, ',BANDED' if banded else '')
					#alignment2 = 'as-123--  DEBUG:(seq{}, {} chars,align_len={}{})'.format(j+1,
					#	len(sequences[j]), align_length, ',BANDED' if banded else '')
###################################################################################################
					s = {'align_cost':score, 'seqi_first100':alignment1, 'seqj_first100':alignment2}
					table.item(i,j).setText('{}'.format(int(score) if score != math.inf else score))
					table.update()
				jresults.append(s)
			results.append(jresults)
		return results


