import numpy

MATCH = -3
INDEL = 5
SUB = 1
class test:
	def __init__(self):
		pass
	def diff(self,x,y):
		return MATCH if x == y else SUB
	def scoring(self, A, B):
		#scoreTable = numpy.zeros((len(A)+1,len(B)+1), dtype = int)
		scoreTable = [[0 for i in range(len(A)+1)],[0 for j in range(len(B)+1)]]
		scoreTable[0,1:] = range(1,len(B)+1)
		scoreTable[1:,0] = range(1,len(A)+1)
		for i in range(1, len(A)+1):
			for j in range(1, len(B)+1):
				scoreTable[i,j] = min(scoreTable[i - 1,j - 1] + self.diff(i,j), scoreTable[i - 1,j] + INDEL,
			                        scoreTable[i,j - 1] + INDEL)
		return scoreTable[len(A),len(B)]

	def ok(self):
		sequence1 = "POLYNOMIAL"
		sequence2 = "EXPONENTIAL"
		score = self.scoring(sequence2, sequence1)
		print(score)

p = test()
p.ok()