#!/usr/bin/python3

from which_pyqt import PYQT_VER
if PYQT_VER == 'PYQT5':
    from PyQt5.QtCore import QLineF, QPointF
elif PYQT_VER == 'PYQT4':
    from PyQt4.QtCore import QLineF, QPointF
else:
    raise Exception('Unsupported Version of PyQt: {}'.format(PYQT_VER))





from TSPClasses import *
import heapq

        
            
class TSPSolver:
    def __init__( self, gui_view ):
        self._scenario = None

    def setupWithScenario( self, scenario ):
        self._scenario = scenario


    ''' <summary>
        This is the entry point for the default solver
        which just finds a valid random tour.  Note this could be used to find your
        initial BSSF.
        </summary>
        <returns>results dictionary for GUI that contains three ints: cost of solution, 
        time spent to find solution, number of permutations tried during search, the 
        solution found, and three null values for fields not used for this 
        algorithm</returns> 
    '''
    def costmatrix(self, cities): #O(n^2)
        lengthcities = len(cities)
        costmat = np.zeros([lengthcities, lengthcities])
        for i in range (0,costmat.shape[0]):
            for j in range (0,costmat.shape[1]):
                if i == j:
                    costmat[i,j] = math.inf
                else:
                    costmat[i,j] = cities[i].costTo(cities[j])
        return costmat

    def reduceRow(self,costmatrix, rownumber): #O(n)
        m = min(costmatrix[rownumber])
        if m == float('inf'):
            return 0
        for i in range(len(costmatrix[rownumber])):
            costmatrix[rownumber][i] -= m
        return m

    def reduceColumn(self,costmatrix, columnnumber): #O(n)
        column = []
        for i in range(len(costmatrix)):
            column.append(costmatrix[i][columnnumber])
        m = min(column)
        if m == float('inf'):
            return 0
        for i in range(len(costmatrix)):
            costmatrix[i][columnnumber] -= m
        return m

    def reduceCostMatrix(self,costmatrix): #O(n)
        lowbound = 0
        for i in range(len(costmatrix)):
            lowbound += self.reduceRow(costmatrix, i)
        for i in range(len(costmatrix)):
            lowbound += self.reduceColumn(costmatrix, i)
        return lowbound
              
    def setColumninf(self,costmatrix, column, value):
        for i in range(len(costmatrix)): #O(n)
            costmatrix[i][column] = value
    
    def setRowinf(self,costmatrix, row, value):
        for i in range(len(costmatrix)): #O(n)
            costmatrix[row][i] = value   
        
    def defaultRandomTour( self, time_allowance=60.0 ):
        results = {}
        cities = self._scenario.getCities()
        ncities = len(cities)
        foundTour = False
        count = 0
        bssf = None
        start_time = time.time()
        while not foundTour and time.time()-start_time < time_allowance:
            # create a random permutation
            perm = np.random.permutation( ncities )
            route = []
            # Now build the route using the random permutation
            for i in range( ncities ):
                route.append( cities[ perm[i] ] )
            bssf = TSPSolution(route)
            count += 1
            if bssf.cost < np.inf:
                # Found a valid route
                foundTour = True
        end_time = time.time()
        results['cost'] = bssf.cost if foundTour else math.inf
        results['time'] = end_time - start_time
        results['count'] = count
        results['soln'] = bssf
        results['max'] = None
        results['total'] = None
        results['pruned'] = None
        return results


    ''' <summary>
        This is the entry point for the greedy solver, which you must implement for 
        the group project (but it is probably a good idea to just do it for the branch-and
        bound project as a way to get your feet wet).  Note this could be used to find your
        initial BSSF.
        </summary>
        <returns>results dictionary for GUI that contains three ints: cost of best solution, 
        time spent to find best solution, total number of solutions found, the best
        solution found, and three null values for fields not used for this 
        algorithm</returns> 
    '''

    def greedy( self,time_allowance=60.0 ):
        pass
    
    
    
    ''' <summary>
        This is the entry point for the branch-and-bound algorithm that you will implement
        </summary>
        <returns>results dictionary for GUI that contains three ints: cost of best solution, 
        time spent to find best solution, total number solutions found during search (does
        not include the initial BSSF), the best solution found, and three more ints: 
        max queue size, total number of states created, and number of pruned states.</returns> 
    '''
        

    def branchAndBound( self, time_allowance=60.0 ): #O(n^2)
    
        ''' <summary>
        This is the entry point for the algorithm you'll write for your group project.
        </summary>
        <returns>results dictionary for GUI that contains three ints: cost of best solution, 
        time spent to find best solution, total number of solutions found during search, the 
        best solution found.  You may use the other three field however you like.
        algorithm</returns> 
        '''        
        starttimer = time.time()
        cities = self._scenario.getCities()
        costmatrix = np.arange(float(len(cities))**2).reshape(len(cities), len(cities))
        for i in range(len(cities)): #O(n)
            for j in range(len(cities)): #O(n)
                costmatrix[i][j] = cities[i].costTo(cities[j])
              
        lowerbound = self.reduceCostMatrix(costmatrix)
        
        priorityqueue = []
        heapq.heappush(priorityqueue, (len(cities) - 1, lowerbound, [0], costmatrix))
        initialbssf = self.defaultRandomTour(time.time())
        bssf = {}
        bssf['cost'] = initialbssf['cost']
        bssf['soln'] = initialbssf['soln']
        bssf['count'] = 1
        
        totalstates = 1
        prunnedstates = 0
        maximumstates = 0
        
        while len(priorityqueue) != 0 and (time.time() - starttimer) < 60: #O(n^2)
            state = heapq.heappop(priorityqueue)
            depth = len(cities) - state[0]
            lowerbound = state[1]
            visited = state[2]
            costmatrix = state[3]
            if depth == len(cities):
                if lowerbound < bssf['cost']:
                    bssf['soln'] = []
                    for i in visited: #O(n)
                        bssf['soln'].append(cities[i])
                    bssf['soln'] = TSPSolution(bssf['soln'])
                    bssf['cost'] = bssf['soln']._costOfRoute()
                    bssf['count'] += 1
                continue

            for i in range(1, len(cities)): #O(n)
                newlowerbound = lowerbound
                if costmatrix[visited[len(visited) - 1]][i] != float('inf'):
                    newcostmatrix = np.array(costmatrix)
                    newlowerbound += newcostmatrix[visited[len(visited) - 1]][i]
                    self.setRowinf(newcostmatrix, visited[len(visited) - 1], float('inf'))
                    self.setColumninf(newcostmatrix, i, float('inf'))
                    newcostmatrix[i][visited[len(visited) - 1]] = float('inf')
                    newlowerbound += self.reduceCostMatrix(newcostmatrix)
                    totalstates += 1
                    if newlowerbound < bssf['cost']:
                        newvisited = list(visited)
                        newvisited.append(i)
                        heapq.heappush(priorityqueue, (len(cities) - depth - 1, newlowerbound, newvisited, newcostmatrix))
                        maximumstates = max(maximumstates, len(priorityqueue))
                        continue
                    prunnedstates += 1
                    
                    
        bssf['time'] = time.time() - starttimer
        print("newstates: " + str(totalstates))
        print("prunnedstates: " + str(prunnedstates))
        print("maximumstates: " + str(maximumstates))
        bssf['max'] = maximumstates
        bssf['total'] = totalstates
        bssf['pruned'] = prunnedstates
        return bssf

        
    def fancy( self,time_allowance=60.0 ):
        pass
        



